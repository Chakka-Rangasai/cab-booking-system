import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-contactus',
  imports: [],
  templateUrl: './contactus.html',
  styleUrl: './contactus.css'
})
export class Contactus {

}
