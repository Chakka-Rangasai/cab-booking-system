export const environment = {
  production: false,
  mapbox: {
    accessToken: 'pk.eyJ1IjoicmFuZ2FzYWk3Nzc3IiwiYSI6ImNtZjFhYmVuMTI1ZGYybHEydWRkMDNnYXEifQ.fPmGEbohyRaO3ooqigDcJg'
  }
};
